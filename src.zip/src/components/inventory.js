import React, { useEffect, useState } from 'react';  
import axios from 'axios';  

const Inventory = ({ refreshInventory }) => {  
    const [inventario, setInventario] = useState([]);  

    useEffect(() => {  
        const fetchInventory = async () => {  
            const response = await axios.get('http://localhost:3000/api/inventario');  
            setInventario(response.data);  
        };  

        fetchInventory();  
    }, [refreshInventory]);  

    const deleteProduct = async (id) => {  
        try {  
            await axios.delete(`http://localhost:3000/api/inventario/${id}`);  
            setInventario(inventario.filter((product) => product.id !== id));  
        } catch (error) {  
            console.error('Error al eliminar el producto', error);  
        }  
    };  

    return (  
        <ul>  
            {inventario.map((product) => (  
                <li key={product.id}>  
                    {product.nombre} - {product.marca} - {product.cantidad}  
                    <button onClick={() => deleteProduct(product.id)}>Eliminar</button>  
                </li>  
            ))}  
        </ul>  
    );  
};  

export default Inventory; 