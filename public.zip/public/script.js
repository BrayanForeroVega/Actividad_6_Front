const apiUrl = 'http://localhost:3000/api/inventario';  

async function fetchInventario() {  
    const response = await fetch(apiUrl);  
    const inventario = await response.json();  
    const inventarioList = document.getElementById('inventarioList');  
    inventarioList.innerHTML = '';  

    inventario.forEach(product => {  
        const li = document.createElement('li');  
        li.innerText = `${product.nombre} - ${product.marca} - ${product.cantidad}`;  
        
        const deleteButton = document.createElement('button');  
        deleteButton.innerText = 'Eliminar';  
        deleteButton.onclick = () => deleteProducto(product.id);  
        li.appendChild(deleteButton);  
        
        inventarioList.appendChild(li);  
    });  
}  

async function addProducto(event) {  
    event.preventDefault();  

    const nombre = document.getElementById('nombre').value;  
    const marca = document.getElementById('marca').value;  
    const cantidad = document.getElementById('cantidad').value;  

    const response = await fetch(apiUrl, {  
        method: 'POST',  
        headers: { 'Content-Type': 'application/json' },  
        body: JSON.stringify({ nombre, marca, cantidad })  
    });  

    if (response.ok) {  
        fetchInventario(); // Actualiza la lista después de agregar  
        document.getElementById('productForm').reset(); // Limpia el formulario  
    }  
}  

async function deleteProducto(id) {  
    const response = await fetch(`${apiUrl}/${id}`, {  
        method: 'DELETE'  
    });  

    if (response.ok) {  
        fetchInventario(); // Actualiza la lista después de eliminar  
    }  
}  

document.getElementById('productForm').addEventListener('submit', addProducto);  
fetchInventario(); // Cargar inventario al inicio